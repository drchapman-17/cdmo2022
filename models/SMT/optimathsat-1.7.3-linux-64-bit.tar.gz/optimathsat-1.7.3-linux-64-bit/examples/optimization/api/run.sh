#!/bin/bash
./api_example -f bacp-19.smt2 -o objective
